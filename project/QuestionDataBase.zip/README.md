# The-Team
this project is a QUESTIONS DATABASE program.
the program contains :

* 1. QUESTIONS DATABASE
* 2. USERS DATABASE
* 3. CLASSES:
  *  Qestion
  *  Student
  *  Lecturer
  *  Coordinator
* 4. DBs to file/ file to DBs functions
* 5. PDF to JPG crop tool
* 6. implement images to PDF tool
* 7. MENU python project to manage all functions and data in the system

@ designed & developed by :
  * Lior Elisberg
  * Eliran Dagan
  * Mendal Amar
  * Nofar Elbaz
          
